'use strict';

// Service utilisé pour accéder à l'API REST des chemins
angular.module('mean.application').factory('TrackService', ['$resource',
  function($resource) {
    return $resource('api/track/:trackId', {
      trackId: '@_id'
    }, {
      update: {
        method: 'PUT'
      }
    });
  }
]);
